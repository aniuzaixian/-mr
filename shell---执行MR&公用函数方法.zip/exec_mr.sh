#!/bin/bash
#set -x
#set -u
set -e 
set -o pipefail  

mr_jar=$1
curr_day=$2

basedir=`dirname $0`
if [ "$basedir" = "." ]
then
    basedir=`pwd`
else
    cd $basedir
fi

emailf=../conf/mailbox.conf
. ../conf/hadoop-conf.sh
. ./pub_funs.sh
. $emailf


if [ "\$$mr_jar" = "$" ]; then
    echo "mr_jar not exists."
    exit 0
fi
if [ ! -e $mr_jar ]; then
    echo "mr_jar not exists."
    exit 0
fi

mails=""
for mail in `cat $emailf`; do
    mails="$mails `echo $mail|cut -f2 -d=`"
done

###################################################################

date "+%Y-%m-%d %H:%M:%S ��ʼ����......" >> $logfile
date "+%Y-%m-%d %H:%M:%S ִ��MR ����......" >> $logfile
exec_task_new 1

exec_task_new 2

exec_task_new 3

date "+%Y-%m-%d %H:%M:%S ���MR ����ִ�С�" >> $logfile
date "+%Y-%m-%d %H:%M:%S ����������" >> $logfile
