#!/bin/bash

# test file/directory exists
function get_hdfs_data()
{
    src_flag=$1
    src_dir=$2
    dest_file=$3
    try_times=0
    max_times=48
    while [ $try_times -lt $max_times ];
    do
        if ($PEOPLE_HADOOP_HOME/hadoop fs -test -e "${src_flag}");
        then
            break
        else
            sleep 300
            ((try_times++))
        fi
    done
    
    if [ $try_times -lt $max_times ];
    then
        $PEOPLE_HADOOP_HOME/hadoop fs -cat ${src_dir}/p* |grep -E "session|apply|update|activate" > ${dest_file}
        if [ -s ${dest_file} ];then
          echo 0
        else
          echo 1
        fi          
    else
        echo 1
    fi
}

fil_test() {
    $PEOPLE_HADOOP_HOME/hadoop fs -test -e $1
    echo $?
}

function hdfs_fil_test() {
    try_times=0
    max_times=48
    while [ $try_times -lt $max_times ];
    do
        if [ `fil_test $1` -eq 0 ]
        then
            echo 0
            break
        else
            try_times=$((try_times + 1))
            sleep 300
        fi
    done
}

can_exec() {
  ret=`hdfs_fil_test $2`
  if [ $ret -ne 0 ]; then
      echo "`date '+%Y-%m-%d %H:%M:%S'` MR$1 input file not exists. exit. " >> $logfile
      send_mail "`date '+%Y-%m-%d %H:%M:%S'` Problem: MR$1 input file not exists." "$mails"
      return;
  fi
  if [ "$IN_DONE_FILE_CHECK_FLAG" = "1" ]; then
      ret=`hdfs_fil_test $2/done`
      if [ $ret -ne 0 ]; then
          echo "`date '+%Y-%m-%d %H:%M:%S'` Problem: dependent MR$1 not executed or failed." >> $logfile
          send_mail "`date '+%Y-%m-%d %H:%M:%S'` Problem: dependent MR$1 not executed or failed." "$mails"
          return;
      fi
  fi
}

# MR_Task
exec_task_new() {
    class=mr$1_class
    in1=mr$1_in1
    in2=mr$1_in2
    in3=mr$1_in3
    in4=mr$1_in4
    out=mr$1_out
    echo "MR$1 ...... " >> $logfile
    
    if [ "\$${!in3}" != "$" ]; then
        (time $PEOPLE_HADOOP_HOME/hadoop jar $mr_jar ${!class} ${!in1} ${!in2} ${!in3} ${!in4} ${!out}) 1>> $logfile 2>> $logfile
    elif [ "\$${!in2}" != "$" ]; then
        echo "`date '+%Y-%m-%d %H:%M:%S'` start exec MR" >> $logfile
        (time $PEOPLE_HADOOP_HOME/hadoop jar $mr_jar ${!class} ${!in1} ${!in2} ${!out}) 1>> $logfile 2>> $logfile
    else
        can_exec $1 ${!in1}
        echo "`date '+%Y-%m-%d %H:%M:%S'` start exec MR" >> $logfile
        (time $PEOPLE_HADOOP_HOME/hadoop jar $mr_jar ${!class} ${!in1} ${!out}) 1>> $logfile 2>> $logfile
    fi
	
    if [ $? -ne 0 ]; then
        echo "`date '+%Y-%m-%d %H:%M:%S'` Problem: There has a exception when running MR$i task." >> $logfile
        send_mail "`date '+%Y-%m-%d %H:%M:%S'` Problem: There has a exception when running MR$i task." "$mails"
        exit $1
    fi
    echo "`date '+%Y-%m-%d %H:%M:%S'` finish exec MR$1" >> $logfile
    echo "`date '+%Y-%m-%d %H:%M:%S'` check done file" >> $logfile
    ret=`fil_test ${!out}/done`
    if [ $ret -ne 0 ]; then
      send_mail "`date '+%Y-%m-%d %H:%M:%S'` MR$1 failed: done file not exists." $mails
      exit $ret
    fi
    echo "MR$1 finish." >> $logfile
    echo "" >> $logfile
}

# send e-mail
send_mail() {
    echo "$1" | mail -s "Error from hadoop" $2
}
