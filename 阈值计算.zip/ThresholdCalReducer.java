/**
     * Project Name: risk_log_prepare
     * File Name: devcheckReducer.java
     * class info: 日志预处理
     * @Author: lixujian
     * @Date: Oct 1, 2016 16:26:48 PM 
     */

package com.people.devcheck.thresholdcal;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URI;
import java.util.*;
import java.util.Map.Entry;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FSDataInputStream;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

import com.people.devcheck.util.DevCheckConstants;
import com.people.devcheck.util.Similarity;
import com.people.devcheck.util.Threshold;

public class ThresholdCalReducer extends Reducer<Text, Text, Text, Text>{
    
    private String prefixCnf = "";
    private String weightValCnf = "";
    private String weightDimCnf = "";
    
    private List<String> iosDimList = new ArrayList<String>();
    private Map<String, Double> iosWeightMap = new HashMap<String, Double>();
    private List<String> androidDimList = new ArrayList<String>();
    private Map<String, Double> androidWeightMap = new HashMap<String, Double>();
    
    private Map<String, String> iosNameMap = new HashMap<String, String>();
    private Map<String, String> androidNameMap = new HashMap<String, String>();
    private List<Double> iosThresholdList = new ArrayList<Double>();
    private List<Double> androidThresholdList = new ArrayList<Double>();
    
    private Map<String, String> iosAllNameMap = new HashMap<String, String>();
    private Map<String, String> androidAllNameMap = new HashMap<String, String>();
    @Override
    protected void setup(Context context) throws IOException {
        Configuration conf = context.getConfiguration();
        prefixCnf = conf.get("prefixCnfStr");
        weightValCnf = conf.get("weightValCnf");
        weightDimCnf = conf.get("weightDimCnf");
        readCnfInfo(context);
    }
    public void parseValCnf(Path valFile, FileSystem fs) throws IOException {

        String s = "";
        FSDataInputStream fin = fs.open(valFile);
        BufferedReader input = new BufferedReader(new InputStreamReader(fin, "UTF-8"));

        try {
            // 处理当前文件数据
            while ((s = input.readLine()) != null) {
                String[] items = s.split("\t");
                if(items.length < 2){
                    continue;
                }
                String type = items[0];
                if(type.contains("Android")){
                    for(int i=1;i<items.length;i++){
                        String[] wKV = items[i].toString().split(":");
                            if(wKV.length < 2){
                                continue;
                            }
                            String wkey = wKV[0];
                            double wvalue = Double.parseDouble(wKV[1]);
                            androidWeightMap.put(wkey, wvalue);
                        }
                }else if(type.contains("Ios")){
                    for(int i=1;i<items.length;i++){
                        String[] wKV = items[i].toString().split(":");
                        if(wKV.length < 2){
                            continue;
                        }
                        String wkey = wKV[0];
                        double wvalue = Double.parseDouble(wKV[1]);
                        iosWeightMap.put(wkey, wvalue);
                    }
                }
            }
        } catch (Exception e) {
            // TODO: handle exception
            e.printStackTrace();
        } finally {
            // 释放
            if (input != null) {
                input.close();
                input = null;
            }
            if (fin != null) {
                fin.close();
                fin = null;
            }
        }
    }

    public void parseDimCnf(Path dimFile, FileSystem fs) throws IOException {

        String s = "";
        FSDataInputStream fin = fs.open(dimFile);
        BufferedReader input = new BufferedReader(new InputStreamReader(fin, "UTF-8"));

        try {
            // 处理当前文件数据
            while ((s = input.readLine()) != null) {
                String[] items = s.split("\t");
                if(items.length < 3){
                    continue;
                }
                String type = items[0];
                String name = items[1];
                String value = items[2].trim();
                if(type.contains("Android")){
                    androidDimList.add(value);
                    androidNameMap.put(value, name);
                }else if(type.contains("Ios")){
                	iosDimList.add(value);
                	iosNameMap.put(value, name);
                }
                if(type.contains("oid")){
                	androidAllNameMap.put(value, name);
                }else if(type.contains("os")){
                	iosAllNameMap.put(value, name);
                }
                
            }
        } catch (Exception e) {
            // TODO: handle exception
            e.printStackTrace();
        } finally {
            // 释放
            if (input != null) {
                input.close();
                input = null;
            }
            if (fin != null) {
                fin.close();
                fin = null;
            }
        }
    }
     
    /*
    * 读取指定HDFS路径下所有文件的数据.
    */
    public void readCnfInfo(Context context) throws IOException {

            if (!iosWeightMap.isEmpty()) {
                iosWeightMap.clear();
            }
            if (!androidWeightMap.isEmpty()) {
                androidWeightMap.clear();
            }
            try {
                FileSystem fs = FileSystem.get(URI.create(prefixCnf), context.getConfiguration());
                // 读取文件列表
                Path valfilePath = new Path(weightValCnf);
                Path dimfilePath = new Path(weightDimCnf);
                // 依次处理每个文件
                parseValCnf(valfilePath, fs);
                parseDimCnf(dimfilePath, fs);
            } catch (Exception e) {
                // TODO: handle exception
                e.printStackTrace();
            }
        }
     
    @Override
    protected void cleanup(Context context) throws IOException, InterruptedException {
    	if(iosWeightMap.size() > 0 && iosAllNameMap.size() > 0){
    		StringBuilder strB = new StringBuilder();
    		for(String key : iosAllNameMap.keySet()){
    			String name = iosAllNameMap.get(key);
    			Double weight = iosWeightMap.containsKey(key) ? iosWeightMap.get(key) : 0.0;
    			strB.append("\t").append(name).append(":").append(String.valueOf(weight));
    		}
    		context.write(new Text("Ios"), new Text("Rec_weight" + strB.toString()));
    	}
    	if(androidWeightMap.size() > 0 && androidAllNameMap.size() > 0){
    		StringBuilder strB = new StringBuilder();
    		for(String key : androidAllNameMap.keySet()){
    			String name = androidAllNameMap.get(key);
    			Double weight = androidWeightMap.containsKey(key) ? androidWeightMap.get(key) : 0.0;
    			strB.append("\t").append(name).append(":").append(String.valueOf(weight));
    		}
    		context.write(new Text("Android"), new Text("Rec_weight" + strB.toString()));
    	}


    	if(iosWeightMap.size() > 0 && iosNameMap.size() > 0){
    		StringBuilder strB = new StringBuilder();
    		for(String key : iosNameMap.keySet()){
    			String name = iosNameMap.get(key);
    			Double weight = iosWeightMap.containsKey(key) ? iosWeightMap.get(key) : 0.0;
    			strB.append("\t").append(name).append(":").append(String.valueOf(weight));
    		}
    		context.write(new Text("Ios"), new Text("Weight" + strB.toString()));
    		Double thd = Threshold.getThreshold(iosThresholdList);
    		context.write(new Text("Ios"), new Text("Threshold" + "\t" + String.valueOf(thd)));
    	}
    	if(androidWeightMap.size() > 0 && androidNameMap.size() > 0){
    		StringBuilder strB = new StringBuilder();
    		for(String key : androidNameMap.keySet()){
    			String name = androidNameMap.get(key);
    			Double weight = androidWeightMap.containsKey(key) ? androidWeightMap.get(key) : 0.0;
    			strB.append("\t").append(name).append(":").append(String.valueOf(weight));
    		}
    		context.write(new Text("Android"), new Text("Weight" + strB.toString()));
    		Double thd = Threshold.getThreshold(androidThresholdList);
    		context.write(new Text("Android"), new Text("Threshold" + "\t" + String.valueOf(thd)));
    	}
    	// 释放数据
        if (!iosWeightMap.isEmpty()) {
            iosWeightMap.clear();
        }
        if (!androidWeightMap.isEmpty()) {
            androidWeightMap.clear();
        }
        if (!iosNameMap.isEmpty()) {
            iosNameMap.clear();
        }
        if (!androidNameMap.isEmpty()) {
            androidNameMap.clear();
        }
        if (!iosAllNameMap.isEmpty()) {
        	iosAllNameMap.clear();
        }
        if (!androidAllNameMap.isEmpty()) {
        	androidAllNameMap.clear();
        }
    }
    
    public void reduce(Text key, Iterable<Text> values,Context context) throws IOException, InterruptedException {
        
        //按datetime排序
        Map<String,String> timeSort = new TreeMap<String,String>();
        for(Text value : values){
            String valLine = value.toString();
            String[] dt = valLine.split("\t",2);
            timeSort.put(dt[0],dt[1]);
        }
        
        List<Double> iosSourceList = new ArrayList<Double>();
        List<Double> iosDataList = new ArrayList<Double>();
        List<Double> iosSimResultList = new ArrayList<Double>();
        
        List<Double> androidSourceList = new ArrayList<Double>();
        List<Double> androidDataList = new ArrayList<Double>();
        List<Double> androidSimResultList = new ArrayList<Double>();

        //遍历Devinfo各维度
        Iterator<Entry<String,String>> it = timeSort.entrySet().iterator();        
        
        boolean iosApplyFlag = false;
        boolean androidApplyFlag = false;
        while(it.hasNext()){            
            Map.Entry<String,String> mp = it.next();            
            //String optTime = mp.getKey();
            String dev = mp.getValue();
            String [] info =  dev.split("\t", 3);
            if(info.length < 3){
                return;
            }
            String intName = info[0];
            String devType = info[1];
            String [] devInfo = info[2].split("\t");
            //按iOS和Android分别遍历
            if(devType.contains("Ios")){
                //iOS用户申请时设备字段信息
                if(intName.contains(DevCheckConstants.INTERNAME_APPLY_FLAG)){
                    iosApplyFlag = true;
                    iosSourceList.clear();
                    for(int i=0;i<devInfo.length;i++){
                    	if(iosDimList.contains(String.valueOf(i))){
                    		double tmpWeight = iosWeightMap.get(String.valueOf(i));
                    		iosSourceList.add(tmpWeight);
                    	}
                    }
                    continue;
                }
                if (!iosApplyFlag){
                    continue;
                }
                iosDataList.clear();
                for(int i=0;i<devInfo.length;i++){
                	if(iosDimList.contains(String.valueOf(i))){
                	    String tmpVal = devInfo[i].toString();
                        if(tmpVal.contains("2")){
                        	double tmpWeight = iosWeightMap.get(String.valueOf(i));
                    	    iosDataList.add(tmpWeight);
                        }else{
                        	iosDataList.add(0.0);
                        }
                	}
                }
                double simVal = Similarity.sim(iosSourceList, iosDataList);
                iosSimResultList.add(simVal);
            }else if(devType.contains("Android")){
                //iOS用户申请时设备字段信息
                if(intName.contains(DevCheckConstants.INTERNAME_APPLY_FLAG)){
                    androidApplyFlag = true;
                    androidSourceList.clear();
                    for(int i=0;i<devInfo.length;i++){
                    	if(androidDimList.contains(String.valueOf(i))){
                    		double tmpWeight = androidWeightMap.get(String.valueOf(i));
                    		androidSourceList.add(tmpWeight);
                    	}
                    }
                    continue;
                }
                if (!androidApplyFlag){
                    continue;
                }
                androidDataList.clear();
                for(int i=0;i<devInfo.length;i++){
                	if(androidDimList.contains(String.valueOf(i))){
                	    String tmpVal = devInfo[i].toString();
                        if(tmpVal.contains("2")){
                        	double tmpWeight = androidWeightMap.get(String.valueOf(i));
                        	androidDataList.add(tmpWeight);
                        }else{
                        	androidDataList.add(0.0);
                        }
                	}
                }
                double simVal = Similarity.sim(androidSourceList, androidDataList);
                androidSimResultList.add(simVal);
            }
        }
        if(iosSimResultList.size() > 0){
        	double minVal = Collections.min(iosSimResultList);
        	if(minVal < 1.0){
        	    iosThresholdList.add(minVal);
        	}
        }
        if(androidSimResultList.size() > 0){
        	double minVal = Collections.min(androidSimResultList);
        	if(minVal < 1.0){
        		androidThresholdList.add(minVal);
        	}
        }
    } 
}
    
