/**
 * Project Name: risk_xian_bank_log_prepare
 * File Name: LogPreDealMapper.java
 * class info: 日志预处理
 * @Author: lixujian
 * @Date: Oct 31, 2016 15:27:09 PM 
 */

package com.people.devcheck.thresholdcal;

import java.io.IOException;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class ThresholdCalMapper extends Mapper<Object, Text, Text, Text> {
	
	    public void map(Object key, Text value, Context context) throws IOException, InterruptedException {

        String line = value.toString();

        //检查空行
        if (line == null || line.trim().isEmpty())
            return;
        String[] lineSplits = line.split("\t", 2);
        if (lineSplits.length < 2)
            return;
        String mkey = lineSplits[0];
        String mvalue = lineSplits[1];
        context.write(new Text(mkey), new Text(mvalue)); 
    }	
}

 
