/**
 * Project Name: devcheck_log_prepare
 * File Name: LogPreDealJob.java
 * Package Name: com.people.devcheck.logpredeal
 * Author: 
 * Date: 2016-11-03 
 * Copyright (c) 2016,lixujian@people2000.net @allRights
 */

package com.people.devcheck.thresholdcal;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.util.GenericOptionsParser;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;

import com.people.devcheck.util.HdfsUtil;

public class ThresholdCalJob extends Configured implements Tool {

    public static void main(String[] args) throws Exception {
        int nRet = ToolRunner.run(new Configuration(), new ThresholdCalJob(), args);
        System.out.println(nRet);
    }

    // 所有如果失敗，需要寫isfail文件

    public int run(String[] args) throws Exception {
        long startTime = System.currentTimeMillis();

        Configuration conf = new Configuration();
        String[] otherArgs = new GenericOptionsParser(conf, args).getRemainingArgs();

        if (otherArgs.length < 5) {
            System.err.println("Usage: <auth_log> <feature_log> <out> <prefix> <conf_file>");
            System.exit(2);
        }

        String prepareWeightCnf = otherArgs[0];
        String onlineWeightCnf = otherArgs[1];
        String prefixCnf = otherArgs[2];
        String fingerDataDir = otherArgs[3];
        String outputDir = otherArgs[otherArgs.length - 1];
        conf.setStrings("prefixCnfStr", prefixCnf);
        conf.setStrings("weightValCnf", prepareWeightCnf);
        conf.setStrings("weightDimCnf", onlineWeightCnf);
        
        Job devCheckJob = Job.getInstance(conf);
        devCheckJob.setJarByClass(ThresholdCalJob.class);

        // M/R configuration
        devCheckJob.setNumReduceTasks(1);
        devCheckJob.setOutputKeyClass(Text.class);
        devCheckJob.setOutputValueClass(Text.class);

        devCheckJob.setMapperClass(ThresholdCalMapper.class);
        devCheckJob.setReducerClass(ThresholdCalReducer.class);
        devCheckJob.setJobName("Dev check threshold Preprocess");

        devCheckJob.setMapOutputKeyClass(Text.class);
        devCheckJob.setMapOutputValueClass(Text.class);

     // 处理输出目录，每次计算之前先查看，如果存在，先删除
        Boolean flag_out = HdfsUtil.fileExist(outputDir);
        if (flag_out) {
            System.out.println("file output is exsited,del it");
            HdfsUtil.deleteDir(outputDir);
        }
        FileOutputFormat.setOutputPath(devCheckJob, new Path(outputDir));

       
        // 认证日志源数据检查
        Boolean flag_in = HdfsUtil.fileExist(fingerDataDir);
        if (flag_in) {
            String in_size = HdfsUtil.getSize(fingerDataDir);

            if (in_size.equals("0Bytes")) {
                System.out.println("pfile is 0bytes");
            } else {
                System.out.println("pfile is " + in_size);
                FileInputFormat.addInputPath(devCheckJob, new Path(fingerDataDir));
            }
        } else {
            System.out.println("input path or file is not exsit");
            System.exit(2);
        }
        int result = devCheckJob.waitForCompletion(true) ? 0 : 1;

        long endTime = System.currentTimeMillis();

        System.out.println("program runs " + (endTime - startTime) / 1000 + " second");

        // 如果运行成功，则写done文件。因为是第一轮MR，所以不需要检查输入中是否有done文件;
        if (devCheckJob.isSuccessful()) {
            HdfsUtil.writeFile(outputDir);
        }

        return result;

    }

}
