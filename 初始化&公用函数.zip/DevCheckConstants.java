package com.people.devcheck.util;
/** 
 * @author User: lixujian
 * @date Date：2016年10月31日 上午10:33:10 
 * 类说明 
 */
public class DevCheckConstants {
	
    public static final String LOG_SEPARATE = "\t";
    public static final int LOG_SPLIT_NUM = 3;

    public static final String NIL_STRING = "nil";
    public static final String NULL_STRING = "null";
    public static final String IL_STRING = "il";

    public static final String LOG_KEY_TIME = "datetime";
    public static final Long LOG_KEY_TEMP = 0L;
    public static final String LOG_KEY_LEVEL = "loglevel";

    public static final String LOG_KEY_USERID = "user_id";
    public static final String LOG_KEY_PHONE = "user_phone";
    public static final String LOG_KEY_APPID = "appId";
    public static final String LOG_KEY_DEVICEID = "devId";
    public static final String LOG_KEY_PLUGINID = "plugin_id";
    public static final String LOG_KEY_VERSION = "version";
    public static final String LOG_KEY_USERIP = "user_ip";
    public static final String LOG_KEY_CITYID = "cityId";// no
    public static final String LOG_KEY_WIFI = "wifi";
    public static final String LOG_KEY_LOCATION = "location";
    public static final String LOG_KEY_PAYEE = "payee";
    public static final String LOG_KEY_PRICE = "price";
    public static final String LOG_KEY_ACTION = "action";
    

    public static final String LOG_KEY_PAYCARD = "payCard";
    public static final String LOG_KEY_PAYCARDTYPE = "cardType";
    public static final String LOG_KEY_RECCARD = "recCard";
    public static final String LOG_KEY_INTNAME = "interface_name";

    public static final String LOG_KEY_WIFI_BSSID = "BSSID";
    public static final String LOG_KEY_WIFI_MAC = "MAC";

    public static final String LOG_PATTERN = "SSID|BSSID|MAC|Supplicantstate|RSSI|Linkspeed|Frequency|NetID|Meteredhint|score";

    public static final String LOG_LEVEL_INFO = "INFO";
    public static final String LOG_CONTENT_RESPONSE = "responseMsg";
    public static final String LOG_CONTENT_REQUEST = "requestMsg";
    public static final String LOG_KEY_DEVINFO = "devInfo=";
 
    public static final String INTERNAME_APPLY_FLAG = "zrauth.plugin.apply2";
    
    public static final String LOG_Android_DEVTYPE = "dev_type";
    public static final String LOG_Android_DEVICEID = "devId";
    public static final String LOG_Android_JOINID = "join_id";
    public static final String LOG_Android_IMEI = "imei";
    public static final String LOG_Android_IMSI = "imsi";
    public static final String LOG_Android_PHONENUM = "phone_num";
    public static final String LOG_Android_PRODUCTTYPE = "product_type";
    public static final String LOG_Android_MANUFACTURER = "manufacturer";
    public static final String LOG_Android_SYSTEMVERSION = "system_version";
    public static final String LOG_Android_SDKVERSION = "sdk_version";
    public static final String LOG_Android_CPU = "cpu";
    public static final String LOG_Android_MAC = "mac";
    public static final String LOG_Android_IP = "ip";
    public static final String LOG_Android_BOARD = "board";
    public static final String LOG_Android_PRODUCT = "product";
    public static final String LOG_Android_FINGERPRINT = "hd_fingerprint";
    public static final String LOG_Android_ANDRIODID = "android_id";
    public static final String LOG_Android_SERIALID = "serial_id";
    public static final String LOG_Android_DISPLAY = "display";
    public static final String LOG_Android_DEVNAME = "dev_name";
    public static final String LOG_Android_ISROOT = "isRoot";
    
    public static final String LOG_IOS_UUID = "uuid";
    public static final String LOG_IOS_MAC = "mac";
    public static final String LOG_IOS_ISROOT = "isRoot";
    public static final String LOG_IOS_DEVNAME = "dev_name";
    public static final String LOG_IOS_DEVTYPE = "dev_type";
    public static final String LOG_IOS_DEVICEID = "devId";
    public static final String LOG_IOS_PRODUCTTYPE = "product_type";
    

}
