/**
 * Project Name: risk_log_prepare
 * File Name: HdfsUtil.java
 * class info:
 * @Author: lixujian
 * @Date: Oct 31, 2016 10:31:18 PM 
 */

package com.people.devcheck.util;

import java.io.IOException;
import java.net.URI;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileStatus;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.FileUtil;
import org.apache.hadoop.fs.Path;

public class HdfsUtil {
    /**
     * @Title: listPaths
     * @param pathStr
     * @Description: 显示hdfs目录下的目录和文件
     *
     */
    public static Path[] listPaths(String uri) {

        try {
            Configuration conf = new Configuration();
            FileSystem fs = FileSystem.get(URI.create(uri), conf);
            FileStatus[] fileStatus = fs.listStatus(new Path(uri));
            return FileUtil.stat2Paths(fileStatus);
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            return new Path[0];
        }

    }

    /**
     * @Title: fileExist
     * @param pathStr
     * @Description: 目录下文件检查是否存在
     */

    public static boolean fileExist(String uri) {

        try {
            Configuration conf = new Configuration();
            FileSystem fileSystem = null;
            fileSystem = FileSystem.get(URI.create(uri), conf);
            return fileSystem.getFileStatus(new Path(uri)) != null;
        } catch (IOException e) {

        }
        return false;

    }

    /**
     * @Title: deleteDir
     * @param pathStr
     * @Description: 递归删除目录下的所有文件及子目录下所有文件
     */
    public static void deleteDir(String uri) {

        try {
            Configuration conf = new Configuration();
            FileSystem fs = FileSystem.get(URI.create(uri), conf);
            fs.delete(new Path(uri), true);
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    /**
     * @Title: getSize
     * @param pathStr
     * @Description: 获取文件的大小
     * 
     */
    public static String getSize(String uri) {

        Configuration conf = new Configuration();
        Path path = new Path(uri);

        long size = 0L;
        FileSystem fs = null;
        try {
            fs = path.getFileSystem(conf);
        } catch (IOException e) {
            e.printStackTrace();
        }
        try {
            size = fs.getContentSummary(path).getLength();
        } catch (IOException e) {
            e.printStackTrace();
        }

        long TB = (size >> 40);
        long GB = (size >> 30) & 0x3ff;
        long MB = (size >> 20) & 0x3ff;
        long KB = (size >> 10) & 0x3ff;
        long B = size & 0x3ff;

        String s = B + "Bytes";
        if (KB != 0) {
            s = KB + "KB " + s;
        }
        if (MB != 0) {
            s = MB + "MB " + s;
        }
        if (GB != 0) {
            s = GB + "GB " + s;
        }
        if (TB != 0) {
            s = TB + "TB " + s;
        }
        return s;
    }

    /**
     * @Title: writeFile
     * @param pathStr
     * @Description: 在指定路径写done文件
     * 
     */
    public static void writeFile(String uri) {

        if (fileExist(uri)) {
            deleteDir(uri + "/done");
        }

        String doneString = "";
        try {
            Configuration conf = new Configuration();
            FileSystem fs = FileSystem.get(URI.create(uri), conf);

            java.io.OutputStream outputStream = fs.create(new Path(uri + "/done"));
            outputStream.write(doneString.getBytes());
            outputStream.flush();
            outputStream.close();

        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    /**
     * @Title: writeFileFail
     * @param pathStr
     *            ，filecontent
     * @Description: 在指定路径写isfail失败文件
     */

    public static void writeFileFail(String uri, String content) {

        if (fileExist(uri)) {
            deleteDir(uri + "/isfail");
        }

        try {
            Configuration conf = new Configuration();
            FileSystem fs = FileSystem.get(URI.create(uri), conf);

            java.io.OutputStream outputStream = fs.create(new Path(uri + "/isfail"));
            outputStream.write(content.getBytes());
            outputStream.flush();
            outputStream.close();

        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    /**
     * @throws IOException
     * 
     * @Title: main
     * @Description: 这里用一句话描述这个方法的作用
     * @param @param args 参数说明
     * @return void 返回类型说明
     * @throws
     */
    public static void main(String[] args) throws IOException {
        // TODO Auto-generated method stub
        // test

//        String url = "hdfs://192.168.1.121:8020/input/log2/";
        String url2 = "hdfs://192.168.1.121:8020/input/log/null.txt";

//        String url_exsit = "hdfs://192.168.1.121:8020/output0";

        // writeFile(url_exsit);
        // deleteDir(url_exsit);

        // for (Path path : listPaths("hdfs://192.168.1.121:8020/input/log/"))
        // System.out.println(path.toString());

        boolean flag = fileExist(url2);
        if (flag) {
            System.out.println("pfile exsit");
            System.out.println("pfile size is " + getSize(url2));

            String fileSize = getSize(url2);
            if (fileSize.equals("0Bytes")) {
                System.out.println("pfile is 0bytes");
            } else {
                System.out.println("pfile is " + fileSize);
            }

        } else {
            System.out.println("pfile not exsit");

        }

    }
}
