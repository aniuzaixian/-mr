package com.people.devcheck.util;

import java.util.List;

public class Threshold {

    public static double getAverage(List<Double> srcList){
		Double sum = 0.0;
		int len = srcList.size();
		for (int i=0; i < len; i++){
			sum += srcList.get(i);
		}
		return (double)sum / len;
	}
    
    public static double getStandardDevition(List<Double> srcList, double average){
		double total = 0.0;
		double len = srcList.size();
		for (int i=0; i < len; i++){
			total += Math.pow((srcList.get(i)-average),2 );
		}
		if(len > 0){
		    return Math.sqrt(total/len);
		}else{
			return 0.0;
		}
	}
    public static double getThreshold(List<Double> srcList){
    	double average = getAverage(srcList);
    	double StandardDevition = getStandardDevition(srcList, average);
    	return average - 3*StandardDevition;
    }
}
