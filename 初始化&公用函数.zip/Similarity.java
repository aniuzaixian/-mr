package com.people.devcheck.util;

import java.util.List;

/** 
 * @author User: lixujian 
 * @date Date：2016年11月9日 下午5:09:52 
 * 类说明 
 */
public class Similarity {

	//求余弦相似度
	public static double sim(List<Double> sourceList,List<Double> dataList){
		double result = 0.0;
		result = pointMulti(sourceList,dataList)/sqrtMulti(sourceList,dataList);
		return result;
	}
	//开根号
	public static double sqrtMulti(List<Double> sourceList,List<Double> dataList){
		double result = 0.0;
		double Sresult = squares(sourceList);
		double Dresult = squares(dataList);
		result = Math.sqrt(Sresult)*Math.sqrt(Dresult);
		return result;
	}
	//求平方和
	public static double squares(List<Double> tmpList){
		double result = 0.0;
		for(int i=0;i<tmpList.size();i++){
			double tVal = tmpList.get(i);
			result += tVal * tVal;
		}
		return result;
	}
	//点乘法
	public static double pointMulti(List<Double> sourceList,List<Double> dataList){
		double result = 0.0;
		for(int i=0;i<sourceList.size();i++){
			result += sourceList.get(i)*dataList.get(i);
		}
		return result;
	}
}
