/**
     * Project Name: risk_log_prepare
     * File Name: devcheckReducer.java
     * class info: 日志预处理
     * @Author: lixujian
     * @Date: Oct 1, 2016 16:26:48 PM 
     */

package com.people.devcheck.logpredeal;

import java.io.IOException;
import java.util.*;
import java.util.Map.Entry;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class LogPreDealReducer extends Reducer<Text, Text, Text, Text>{
    
    public void reduce(Text key, Iterable<Text> values,Context context) throws IOException, InterruptedException {
        
        Map<String,String> timeSort = new TreeMap<String,String>();
        for(Text value : values){
        	String valLine = value.toString();
            String[] dt = valLine.split("\t",2);
            timeSort.put(dt[0],dt[1]);
        }
        
        String userApplyFlag = "zrauth.plugin.apply2";
        StringBuilder devResult = new StringBuilder(); 
        
        List<String> devIosVecList = new ArrayList<String>();
        List<String> applyIosList = new ArrayList<String>();
        List<String> iosOtherList = new ArrayList<String>();
        
        List<String> devAndroidVecList = new ArrayList<String>();
        List<String> applyAndroidList = new ArrayList<String>();
        List<String> androidOtherList = new ArrayList<String>();
        
        Iterator<Entry<String,String>> it = timeSort.entrySet().iterator();        
        
        boolean iosApplyFlag = false;
        boolean androidApplyFlag = false;
        boolean checkSimFlag = false;
        while(it.hasNext()){            
            Map.Entry<String,String> mp = it.next();            
            String optTime = mp.getKey();
            String dev = mp.getValue();
            String [] info =  dev.split("\t", 3);
            if(info.length < 3){
                return;
            }
            
            String intName = info[0];
            String devType = info[1];
            String [] devInfo = info[2].split("\t");
            
            if(devType.contains("Ios")){
                if(intName.contains(userApplyFlag)){
                    iosApplyFlag = true;
                    applyIosList.clear();
                    devResult.delete(0, devResult.length());
                    devResult.append(optTime);
                    devResult.append("\t").append(intName);
                    devResult.append("\t").append(devType);
                    for(String apply : devInfo){
                        applyIosList.add(apply);
                        devResult.append("\t").append("2");
                    }
                    devIosVecList.add(devResult.toString());
                    continue;
                }
                if (!iosApplyFlag){
                    continue;
                }
                iosOtherList.clear();
                for(String other : devInfo){
                    iosOtherList.add(other);
                }
                devResult.delete(0, devResult.length());
                devResult.append(optTime);
                devResult.append("\t").append(intName);
                devResult.append("\t").append(devType);
                for(int i=0;i<applyIosList.size();i++){
                    String otherVal = iosOtherList.get(i);
                    String applyVal = applyIosList.get(i);
                    if(otherVal.contains(applyVal)){
                        devResult.append("\t").append("2");
                    }else{
                	    checkSimFlag = true;
                        devResult.append("\t").append("1");
                    }
                }
                devIosVecList.add(devResult.toString());
            }else if(devType.contains("Android")){
                if(intName.contains(userApplyFlag)){
                    androidApplyFlag = true;
                    applyAndroidList.clear();
                    devResult.delete(0, devResult.length());
                    devResult.append(optTime);
                    devResult.append("\t").append(intName);
                    devResult.append("\t").append(devType);
                    for(String apply : devInfo){
                        applyAndroidList.add(apply);
                        devResult.append("\t").append("2");
                    }
                    devAndroidVecList.add(devResult.toString());
                    continue;
                }
                if (!androidApplyFlag){
                    continue;
                }
                androidOtherList.clear();
                for(String other : devInfo){
                    androidOtherList.add(other);
                }
                devResult.delete(0, devResult.length());
                devResult.append(optTime);
                devResult.append("\t").append(intName);
                devResult.append("\t").append(devType);
                for(int i=0;i<applyAndroidList.size();i++){
                    String otherVal = androidOtherList.get(i);
                    String applyVal = applyAndroidList.get(i);
                    if(otherVal.contains(applyVal)){
                        devResult.append("\t").append("2");
                    }else{
                	    checkSimFlag = true;
                        devResult.append("\t").append("1");
                    }
                }
                devAndroidVecList.add(devResult.toString());
            }
        
        }
        
        if(checkSimFlag){
        	for(int i=0;i<devIosVecList.size();i++){
        		String val = devIosVecList.get(i);
        		context.write(key, new Text(val));
        	}
        	for(int i=0;i<devAndroidVecList.size();i++){
        		String val = devAndroidVecList.get(i);
        		context.write(key, new Text(val));
        	}
        }
    }     
}
    
