/**
 * Project Name: risk_xian_bank_log_prepare
 * File Name: LogPreDealMapper.java
 * class info: 日志预处理
 * @Author: lixujian
 * @Date: Oct 31, 2016 15:27:09 PM 
 */

package com.people.devcheck.logpredeal;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URI;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.codec.binary.Base64;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FSDataInputStream;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.people.devcheck.util.DevCheckConstants;
import com.people.devcheck.util.isValidDate;

public class LogPreDealMapper extends Mapper<Object, Text, Text, Text> {
	
	List<String> andriodSegList = new ArrayList<String>();
	List<String> iosSegList = new ArrayList<String>();
    
	private String prefixCnf = "";
    private String valueCnf = "";
	
	@Override
    protected void setup(Context context)
        throws IOException, InterruptedException {       
        Configuration conf = context.getConfiguration();
        prefixCnf = conf.get("prefixCnfStr");
        valueCnf = conf.get("valueCnf");
        readCnfInfo(context);
	}
    public void parseValCnf(Path valFile, FileSystem fs) throws IOException {
        String s = "";
        FSDataInputStream fin = fs.open(valFile);
        BufferedReader input = new BufferedReader(new InputStreamReader(fin, "UTF-8"));

        try {
        	Map<String, String> iosNameMap = new HashMap<String, String>();
        	Map<String, String> androidNameMap = new HashMap<String, String>();
            // 处理当前文件数据
            while ((s = input.readLine()) != null) {
                String[] items = s.split("\t");
                if(items.length < 3){
                    continue;
                }
                String type = items[0].trim();
                String name = items[1].trim();
                String value = items[2].trim();
                
                if(type.contains("oid")){
                	androidNameMap.put(value, name);
                }else if(type.contains("os")){
                	iosNameMap.put(value, name);
                }    
            }
            for(int i=0;i<iosNameMap.size();i++){
            	if(iosNameMap.containsKey(String.valueOf(i))){
            		iosSegList.add(iosNameMap.get(String.valueOf(i)));
            	}else{
            		iosSegList.add("nil");
            	}
            }
            for(int i=0;i<androidNameMap.size();i++){
            	if(androidNameMap.containsKey(String.valueOf(i))){
            		andriodSegList.add(androidNameMap.get(String.valueOf(i)));
            	}else{
            		andriodSegList.add("nil");
            	}
            }
            if(!iosNameMap.isEmpty()){
            	iosNameMap.clear();
            }
            if(!androidNameMap.isEmpty()){
            	androidNameMap.clear();
            }
        } catch (Exception e) {
            // TODO: handle exception
            e.printStackTrace();
        } finally {
            // 释放
            if (input != null) {
                input.close();
                input = null;
            }
            if (fin != null) {
                fin.close();
                fin = null;
            }
        }
    }
    /*
    * 读取指定HDFS路径下所有文件的数据.
    */
    public void readCnfInfo(Context context) throws IOException {

        try {
            FileSystem fs = FileSystem.get(URI.create(prefixCnf), context.getConfiguration());
            // 读取文件列表
            Path valfilePath = new Path(valueCnf);
            
            parseValCnf(valfilePath, fs);
        } catch (Exception e) {
            // TODO: handle exception
            e.printStackTrace();
        }
    }

    public void map(Object key, Text value, Context context) throws IOException, InterruptedException {

        String line = value.toString();

        //检查空行
        if (line == null)
            return;
        if (line.trim().isEmpty())
            return;
        // 检查总体格式
        String[] lineSplits = line.split(" - ");
        if (lineSplits.length != DevCheckConstants.LOG_SPLIT_NUM)
            return;
        // 检查日期
        String timeString = line.substring(line.indexOf("[") + 1, line.indexOf("]"));
        if (!isValidateTime(timeString))
            return;
        //检查devInfo
        String devinf = lineSplits[1];
        if (!isValidateDevInfo(devinf))
            return;           
        
        Map<String, String> dataMap = new HashMap<String, String>();
        
        //Time
        String dateString = timeString.substring(0, timeString.indexOf(".") - 1);
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
        Date date;
        Long timeStemp = 0L;
        try {
            date = simpleDateFormat.parse(dateString);
            timeStemp = date.getTime() / 1000;
        } catch (ParseException e) {
            // TODO Auto-generated catch block
        }
        dataMap.put(DevCheckConstants.LOG_KEY_TIME, timeStemp.toString());
        
        //userPhone & intName 
        String contentLog = lineSplits[2].replaceAll(" ", "");
        getLogInfo(dataMap, contentLog);      

        //devInfo
        String dev1 = lineSplits[1].substring(lineSplits[1].indexOf("devInfo=") + 8);
        String dev2 = dev1.split(",")[0];
        String devInfo = new String(Base64.decodeBase64(dev2));
        
        JSONObject devJsonObj = null;
        try{
            devJsonObj = JSON.parseObject(devInfo);
        }
        catch(Exception e){
            e.printStackTrace();
        }

        if (devJsonObj.isEmpty()){
            return;
        }
        if( ! devJsonObj.containsKey("dev_type")){
            return;
        }
        String tmpDevType = devJsonObj.getString("dev_type");
        StringBuilder devDestInfo = new StringBuilder();
        String seg_value = "";
        if(tmpDevType.contains("Ios")){
            devDestInfo.append("Ios");
            for(String seg_id: iosSegList){
                
                if(devJsonObj.containsKey(seg_id)){    
                    seg_value = devJsonObj.getString(seg_id).trim();
                    if(seg_value.length() <= 0){
                        seg_value = "nil";
                    }
                }else{
                    seg_value = "nil";        
                }
                devDestInfo.append("\t").append(seg_value);
            }          	
        }else if (tmpDevType.contains("Android")){
        	devDestInfo.append("Android");
        	for(String seg_id: andriodSegList){
	 	        if(devJsonObj.containsKey(seg_id)){	
	 	            seg_value = devJsonObj.getString(seg_id).trim();
	 	            if(seg_value.length() <= 0){
	 	            	seg_value = "nil";
	 	            }
                }else{
                    seg_value = "nil";    	
                }
	 	        devDestInfo.append("\t").append(seg_value);
	 	    }          	
        }else{
        	return;
        }
        String userId = dataMap.get(DevCheckConstants.LOG_KEY_PHONE);
        String timeStr = dataMap.get(DevCheckConstants.LOG_KEY_TIME);
        String intname = dataMap.get(DevCheckConstants.LOG_KEY_INTNAME);
        context.write(new Text(userId), new Text(timeStr + "\t" + intname + "\t" + devDestInfo.toString())); 
    } 
       
    //检查时间
    public static Boolean isValidateTime(String timeString) {

        if (timeString != null) {
            if (!timeString.trim().isEmpty()) {
                if (timeString.contains(".")) {
                    String dateString = timeString.substring(0, timeString.indexOf(".") - 1);
                    if (isValidDate.validDate(dateString)) {
                        return true;
                    }
                }
            }
        }
        return false;
    }
    //包含devInfo信息
    public static Boolean isValidateDevInfo(String devInfo) {
        if (devInfo != null) {
            if (!devInfo.trim().isEmpty()) {
                if (devInfo.contains(DevCheckConstants.LOG_KEY_DEVINFO)) {
                    return true;
                }
            }
        }
    return false;
} 
    
    // get log map
    public static void getLogInfo(Map<String, String> dataMap, String contentLog) {
        String[] tokens = contentLog.split("]");

        for (String token : tokens) {
            String key = token.substring(1, token.indexOf(":"));
            getSegContent(key, token, dataMap);
        }
    }
    //userPhone & intName
    public static void getSegContent(String key, String token, Map<String, String> dataMap) {

        if (DevCheckConstants.LOG_KEY_PHONE.equals(key)) {
            String userphonestring = token.substring(token.indexOf(":") + 1);
            if (userphonestring.trim().isEmpty() || DevCheckConstants.NIL_STRING.equals(userphonestring.trim())
                    || DevCheckConstants.NULL_STRING.equals(userphonestring.trim())) {
            	userphonestring = DevCheckConstants.NIL_STRING;
            }
            dataMap.put(DevCheckConstants.LOG_KEY_PHONE,userphonestring);
        }
        if (DevCheckConstants.LOG_KEY_INTNAME.equals(key)) {

            String interfstring = token.substring(token.indexOf(":") + 1);
            dataMap.put(DevCheckConstants.LOG_KEY_INTNAME,interfstring);
        }
    }
    	    	
}

 
