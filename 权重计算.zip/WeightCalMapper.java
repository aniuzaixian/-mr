/**
 * Project Name: risk_xian_bank_log_prepare
 * File Name: LogPreDealMapper.java
 * class info: 日志预处理
 * @Author: lixujian
 * @Date: Oct 31, 2016 15:27:09 PM 
 */

package com.people.devcheck.weightcal;

import java.io.IOException;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class WeightCalMapper extends Mapper<Object, Text, Text, Text> {
	
	    public void map(Object key, Text value, Context context) throws IOException, InterruptedException {

        String line = value.toString();

        //检查空行
        if (line == null)
            return;
        if (line.trim().isEmpty())
            return;
        String[] lineSplits = line.split("\t", 5);
        if (lineSplits.length != 5)
            return;
        String devType = lineSplits[3];
        String otherData = lineSplits[4];
        context.write(new Text(devType), new Text(otherData)); 
    }     	    	
}

 
