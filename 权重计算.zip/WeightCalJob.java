/**
 * Project Name: devcheck_log_prepare
 * File Name: LogPreDealJob.java
 * Package Name: com.people.devcheck.logpredeal
 * Author: 
 * Date: 2016-11-03 
 * Copyright (c) 2016,lixujian@people2000.net @allRights
 */

package com.people.devcheck.weightcal;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.util.GenericOptionsParser;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;

import com.people.devcheck.util.HdfsUtil;

public class WeightCalJob extends Configured implements Tool {

    public static void main(String[] args) throws Exception {
        int nRet = ToolRunner.run(new Configuration(), new WeightCalJob(), args);
        System.out.println(nRet);
    }

    // 所有如果失敗，需要寫isfail文件

    @Override
    public int run(String[] args) throws Exception {
        long startTime = System.currentTimeMillis();

        Configuration conf = new Configuration();
        String[] otherArgs = new GenericOptionsParser(conf, args).getRemainingArgs();

        if (otherArgs.length < 2) {
            System.err.println("Usage: input_dir <input_dir> output_dir");
            System.exit(2);
        }

        Job devCheckJob = Job.getInstance(conf);
        devCheckJob.setJarByClass(WeightCalJob.class);

        // M/R configuration
        devCheckJob.setNumReduceTasks(1);
        devCheckJob.setOutputKeyClass(Text.class);
        devCheckJob.setOutputValueClass(Text.class);

        devCheckJob.setMapperClass(WeightCalMapper.class);
        devCheckJob.setReducerClass(WeightCalReducer.class);
        devCheckJob.setJobName("Dev check log prepare Preprocess");

        devCheckJob.setMapOutputKeyClass(Text.class);
        devCheckJob.setMapOutputValueClass(Text.class);

        // 处理输出目录，每次计算之前先查看，如果存在，先删除

        String url_output = otherArgs[otherArgs.length - 1];
        Boolean flag_out = HdfsUtil.fileExist(url_output);
        if (flag_out) {
            System.out.println("file output is exsited,del it");
            HdfsUtil.deleteDir(url_output);
        }

        FileOutputFormat.setOutputPath(devCheckJob, new Path(otherArgs[otherArgs.length - 1]));

        try {

            for (int i = 0; i < otherArgs.length - 1; ++i) {
                // 处理输入目录或文件，如果其不存在，则过滤掉。如果存在，但是文件内容为空，也过滤掉。
                String url_input = otherArgs[i];
                Boolean flag_in = HdfsUtil.fileExist(url_input);
                if (flag_in) {
                    String in_size = HdfsUtil.getSize(url_input);

                    if (in_size.equals("0Bytes")) {
                        System.out.println("pfile is 0bytes");
                    } else {
                        System.out.println("pfile is " + in_size);
                        FileInputFormat.addInputPath(devCheckJob, new Path(otherArgs[i]));

                    }
                } else {
                    System.out.println("input path or file is not exsit");
                }
            }

            int in = FileInputFormat.getInputPaths(devCheckJob).length;
            if (in == 0) {
                
                System.err.println("Usage: input file is null");
                System.exit(2);
            }

        } catch (Exception e) {
            // TODO: handle exception
            System.out.println(e);
        }

        int result = devCheckJob.waitForCompletion(true) ? 0 : 1;

        long endTime = System.currentTimeMillis();

        System.out.println("program runs " + (endTime - startTime) / 1000 + " second");

        // 如果运行成功，则写done文件。因为是第一轮MR，所以不需要检查输入中是否有done文件;
        if (devCheckJob.isSuccessful()) {
            HdfsUtil.writeFile(url_output);
        }

        return result;

    }

}
