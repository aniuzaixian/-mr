/**
     * Project Name: risk_log_prepare
     * File Name: devcheckReducer.java
     * class info: 日志预处理
     * @Author: lixujian
     * @Date: Oct 1, 2016 16:26:48 PM 
     */

package com.people.devcheck.weightcal;

import java.io.IOException;
import java.util.*;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class WeightCalReducer extends Reducer<Text, Text, Text, Text>{
    
    public void reduce(Text key, Iterable<Text> values,Context context) throws IOException, InterruptedException {
        
    	Map<Integer, Integer> devOkWeightMap = new HashMap<Integer, Integer>();
    	Map<Integer, Integer> devErrWeightMap = new HashMap<Integer, Integer>();
        for(Text value : values){
        	String valLine = value.toString();
        	String []valTokens = valLine.split("\t");
        	for(int i=0;i<valTokens.length;i++){
        		if(! devOkWeightMap.containsKey(i)){
    				devOkWeightMap.put(i, 0);
    			}
        		if(! devErrWeightMap.containsKey(i)){
    				devErrWeightMap.put(i, 0);
    			}
        		String segVal = valTokens[i].toString();
        		if(segVal.equals("2")){
        			if(devOkWeightMap.containsKey(i)){
        		        devOkWeightMap.put(i, devOkWeightMap.get(i)+1);
        			}
        		}else if(segVal.equals("1")){
        			if(devErrWeightMap.containsKey(i)){
        		        devErrWeightMap.put(i, devErrWeightMap.get(i)+1);
        			}
        		}
        	}
        }
        
        StringBuilder devWeightInfo = new StringBuilder();
        for(int i = 0; i < devOkWeightMap.size();i++){
        	double okRate = 1.0;
        	double errRate = 0.0;
        	double xiangNongShang = 0.0;
        	if(devErrWeightMap.containsKey(i)){
        		if(devErrWeightMap.get(i) > 0.0){
        		    okRate = (double)devOkWeightMap.get(i) / (devErrWeightMap.get(i) + devOkWeightMap.get(i));
        		    errRate = 1.0 - okRate;
        		    xiangNongShang = - (okRate*Math.log(okRate)/Math.log(2) + errRate*Math.log(errRate)/Math.log(2));
        	    }else{
        		    xiangNongShang = 0.0;
        	    }
        	}
        	double weightVal = 1.0 - xiangNongShang;
        	devWeightInfo.append("\t" + Integer.toString(i) + ":" + weightVal);
        }
        
        context.write(null, new Text(key + devWeightInfo.toString()));
        
    }     
}
    
